print("Welcome To My First Game!")
name = input("Siapa nama mu?")
age = int(input("Berapa usia mu sekarang?"))

print("Halo",name,"usia mu",age,"tahun")
health=100


if age >=18:
    print("Kamu sudah cukup umur untuk bermain!")

    mau_bermain=input("Apakah kamu siap bermain?(yes/no)").lower()
    if mau_bermain=="yes":
        print("Lets GO")
        print("Kamu mulai dengan",health,"nyawa")

        kanan_atau_kiri =input("Pilihan Pertama..Kanan atau Kiri(kanan/kiri)")
        if kanan_atau_kiri=="kanan":
            ans=input("Selamat anda memilih jalan yang benar dan telah sampai di danau..Sekarang kamu pilih berenang atau memutari danau?")
            
            if ans=="berenang":
                print("kamu telah berhasil sampai di tepi danau")

            elif ans=="memutari":
                print("kamu berhasil memutari danau tapi tiba tiba ada serigala di depan mu dan kamu kehilangan 50 nyawa mu ")
                health-=50

            ans=input("kamu melihat rumah dan sungai mana yang kamu pilih(rumah/sungai)")
            if ans=="rumah":
                print("kamu pergi kerumah dan pemilik rumah melemper mu dengan piring kamu kehilangan 50 nyawa mu ")
                health-=50

                if health <=0:
                    print=("kamu sekarang memilik 0 nyawa dan kamu kalah kali ini...")
                else:
                    print:("kamu berhasil selamat")    


            else:
                print("kamu terbawa arus sungai dan hilang..")       



        else:
                print("kamu terjatuh dan kalah,coba jalan yang lain")
               
    else:
      print("hmmm... see you")      
else:
    print("Maaf kamu belum cukup umur untuk bermain );")